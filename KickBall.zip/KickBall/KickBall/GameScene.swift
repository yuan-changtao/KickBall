//
//  GameScene.swift
//  KickBall
//
//  Created by Yct on 2021/11/15.
//

import SpriteKit
import GameplayKit

let MASK_EDGE:UInt32 = 0b1
let MASK_BALL:UInt32 = 0b10
let MASK_FLAG:UInt32 = 0b100



class GameScene: SKScene, SKPhysicsContactDelegate {
    
    var gameStarted:Bool!
    var ball:SKSpriteNode!
    var startGameLabel:SKLabelNode!
    
    override func didMove(to view: SKView) {
        gameStarted = false
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        physicsBody?.contactTestBitMask = MASK_EDGE
        physicsWorld.contactDelegate = self
        ball = (childNode(withName: "ball") as! SKSpriteNode)
        startGameLabel = (childNode(withName: "startGameLabel") as! SKLabelNode)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if gameStarted {
            // add flags
            let flag = SKSpriteNode(imageNamed: "flag1")
            addChild(flag)
            flag.physicsBody = SKPhysicsBody(rectangleOf: flag.frame.size)
            flag.position = ((touches as NSSet).anyObject()! as AnyObject).location(in: self)
            flag.physicsBody?.contactTestBitMask = MASK_FLAG
            flag.physicsBody?.velocity = CGVector(dx: 0, dy: 500)
        }
        else {
            gameStarted = true
            startGameLabel.isHidden = true
            ball.physicsBody = SKPhysicsBody(circleOfRadius: ball.frame.size.width/2)
            ball.physicsBody?.contactTestBitMask = MASK_BALL
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        let maskCode = contact.bodyA.contactTestBitMask|contact.bodyB.contactTestBitMask
        if maskCode == MASK_EDGE|MASK_FLAG {
            if contact.bodyA.contactTestBitMask == MASK_FLAG {
                contact.bodyA.node?.removeFromParent()
            }
            if contact.bodyB.contactTestBitMask == MASK_FLAG {
                contact.bodyB.node?.removeFromParent()
            }
        }
        else if maskCode == MASK_EDGE|MASK_BALL {
            self.view?.presentScene(GameOverScene(size: self.frame.size))
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
