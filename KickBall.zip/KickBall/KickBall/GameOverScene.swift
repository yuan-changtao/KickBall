//
//  GameOverScene.swift
//  KickBall
//
//  Created by Yct on 2021/11/15.
//

import Foundation
import SpriteKit

class GameOverScene:SKScene {
    override init(size:CGSize) {
        super.init(size: size)
        
        let label = SKLabelNode()
        label.text = "游戏结束"
        label.position = CGPoint(x: size.width/2, y: size.height/2)
        addChild(label)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
